
			<footer>
			   <p>&copy 2018 البرخن Member Panel. All Rights Reserved | Design by <a href="" target="_blank">Softra Global</a></p>
			</footer>
     

   </section>
  
<script src="js/jquery.nicescroll.js"></script>
<script src="js/scripts.js"></script>

   <script src="js/bootstrap.min.js"></script>
</body>
</html>